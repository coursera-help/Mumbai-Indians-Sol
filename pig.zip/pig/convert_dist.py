@outputSchema("dist_readings:{(year:int, totDist:float, totPassVech:float)}")
def converDist(distancesMiles):
	year, totDist, totPassVech = distancesMiles.split(',');
	totDist_m = totDist / 0.62;
	return year, totDist_m, totPassVech
